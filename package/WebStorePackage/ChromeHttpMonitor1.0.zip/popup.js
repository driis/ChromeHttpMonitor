var addNameValue, renderCookies, renderDetails, renderHeaders, renderPopup;

renderPopup = function(tab, page) {
  var tabInfo;
  tabInfo = findTabInfo(tab.id, page);
  console.log(tabInfo);
  if (tabInfo != null) {
    renderDetails(tabInfo);
    renderCookies(tabInfo);
    renderHeaders(tabInfo);
  } else {
    $("#notShown").text("This frame has content that is not supported, or it was loaded while the extension was not running.");
    $("#container").hide();
  }
  return null;
};

renderDetails = function(tabInfo) {
  var mainRequest, responseTime, urlLink;
  urlLink = $("#url");
  urlLink.text(tabInfo.url);
  urlLink.attr("href", tabInfo.url);
  urlLink.attr("alt", tabInfo.url);
  responseTime = tabInfo.totalResponseTime();
  $("#loadTime").text(responseTime.toString());
  mainRequest = tabInfo.getMainRequest();
  if (mainRequest != null) {
    $("#initialRequestTime").text(mainRequest.totalResponseTime());
    $("#hostIp").text(mainRequest.ip);
  }
  if (tabInfo.requests != null) {
    return $("#resources").text((Object.keys(tabInfo.requests)).length);
  }
};

renderHeaders = function(tabInfo) {
  var container, header, _i, _len, _ref, _results;
  if ((tabInfo.mainRequest != null) && (tabInfo.mainRequest.headers != null)) {
    container = $("#headers");
    _ref = tabInfo.mainRequest.headers;
    _results = [];
    for (_i = 0, _len = _ref.length; _i < _len; _i++) {
      header = _ref[_i];
      _results.push(addNameValue(header, container));
    }
    return _results;
  }
};

renderCookies = function(tabInfo) {
  return chrome.cookies.getAll({
    url: tabInfo.url
  }, function(cookies) {
    var container, cookie, _i, _len, _results;
    container = $("#cookies");
    _results = [];
    for (_i = 0, _len = cookies.length; _i < _len; _i++) {
      cookie = cookies[_i];
      _results.push(addNameValue(cookie, container));
    }
    return _results;
  });
};

addNameValue = function(cookie, container) {
  var c, htmlLabel, htmlTextBox, name;
  name = cookie.name;
  htmlLabel = "<label for='" + name + "'>" + name + ":</label>";
  htmlTextBox = "<input name='" + name + "' type='text' value='" + cookie.value + "'/>";
  return c = container.append(htmlLabel, htmlTextBox);
};
