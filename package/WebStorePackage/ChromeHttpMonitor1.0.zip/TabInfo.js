var TabInfo, findRequest, findTabInfo, getSelectedTab, registerRequest, requestCompleted, setNavigationBegin, setNavigationCompleted, setTabInfo;

findTabInfo = function(tabId, win) {
  if (win == null) win = window;
  return win.headerbag[tabId];
};

setTabInfo = function(args) {
  var info;
  info = new TabInfo(args);
  return window.headerbag[args.tabId] = info;
};

getSelectedTab = function(callback) {
  return chrome.windows.getCurrent(function(window) {
    return chrome.tabs.query({
      windowId: window.id,
      active: true
    }, function(tabs) {
      return callback(tabs[0]);
    });
  });
};

setNavigationBegin = function(tab) {
  var tabInfo;
  tabInfo = findTabInfo(tab.tabId);
  if (tabInfo != null) return tabInfo.navigationBegin = tab.timestamp;
};

setNavigationCompleted = function(tab) {
  var responseTime, tabInfo, text;
  tabInfo = findTabInfo(tab.tabId);
  tabInfo.timeStampEnd = tab.timeStamp;
  responseTime = tabInfo.totalResponseTime();
  text = responseTime.toString();
  if (responseTime <= 1000) {
    chrome.browserAction.setIcon({
      path: "icons/fast_button.png",
      tabId: tab.tabId
    });
    chrome.browserAction.setBadgeBackgroundColor({
      color: [0, 160, 0, 200],
      tabId: tab.tabId
    });
  }
  if (responseTime > 1000 && responseTime <= 2400) {
    chrome.browserAction.setIcon({
      path: "icons/medium_button.png",
      tabId: tab.tabId
    });
  }
  if (responseTime > 2400) {
    chrome.browserAction.setIcon({
      path: "icons/slow_button.png",
      tabId: tab.tabId
    });
  }
  return chrome.browserAction.setBadgeText({
    text: text,
    tabId: tab.tabId
  });
};

registerRequest = function(req) {
  var tabInfo;
  if (req.type === "main_frame") {
    tabInfo = setTabInfo(req);
    tabInfo.mainRequest = req;
  } else {
    tabInfo = findTabInfo(req.tabId);
  }
  if (tabInfo != null) {
    tabInfo.requests[req.requestId] = req;
    return req.totalResponseTime = function() {
      return Math.round(this.timeStampEnd - this.timeStamp);
    };
  }
};

findRequest = function(req) {
  var tabInfo;
  tabInfo = findTabInfo(req.tabId);
  if (tabInfo != null) {
    return tabInfo.requests[req.requestId];
  } else {
    return null;
  }
};

requestCompleted = function(req) {
  var reqStored;
  reqStored = findRequest(req);
  if (reqStored != null) {
    reqStored.timeStampEnd = req.timeStamp;
    reqStored.ip = req.ip;
    return reqStored.headers = req.responseHeaders;
  }
};

TabInfo = (function() {

  TabInfo.name = 'TabInfo';

  TabInfo.timeStampEnd = null;

  TabInfo.navigationBegin = null;

  TabInfo.requests = [];

  TabInfo.prototype.totalResponseTime = function() {
    if (this.timeStampEnd != null) {
      return Math.round(this.timeStampEnd - this.timeStampBegin);
    }
  };

  TabInfo.prototype.getMainRequest = function() {
    return this.mainRequest;
  };

  function TabInfo(tab) {
    this.timeStampBegin = tab.timeStamp;
    this.url = tab.url;
    this.requests = [];
  }

  return TabInfo;

})();

window.headerbag = new Array();
