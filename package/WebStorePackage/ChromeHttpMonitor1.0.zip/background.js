var beforeNavigate, navigationCompleted, urlFilter;

urlFilter = {
  urls: ["http://*/*", "https://*/*"]
};

beforeNavigate = function(args) {
  console.log("BeforeNavigate Tab", args);
  if (args.frameId === 0) return setNavigationBegin(args);
};

navigationCompleted = function(args) {
  console.log("Navigation Completed Tab", args);
  if (args.frameId === 0) return setNavigationCompleted(args);
};

chrome.webRequest.onBeforeRequest.addListener(registerRequest, urlFilter);

chrome.webRequest.onCompleted.addListener(requestCompleted, urlFilter, ["responseHeaders"]);

chrome.webNavigation.onBeforeNavigate.addListener(beforeNavigate);

chrome.webNavigation.onCompleted.addListener(navigationCompleted);
